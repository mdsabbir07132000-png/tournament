#!/usr/bin/env python3
"""
Free Fire Tournament Bot
Supports: BR (40 players), CS 4v4, LONE WOLF 1v1
Admin ID: 8690101844
"""

import logging
import json
import os
from datetime import datetime
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes, ConversationHandler
)

# ─────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────
BOT_TOKEN  = "8943230974:AAEmLULTTzacbPlZLqV3_s5e2706dw2cI-k"
ADMIN_IDS  = [8690101844]
DATA_FILE  = "tournament_data.json"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ConversationHandler states
(
    CREATE_NAME, CREATE_TYPE, CREATE_DATE, CREATE_TIME,
    CREATE_PRIZE, CREATE_ENTRY_FEE, CREATE_ROOM_ID, CREATE_ROOM_PASS,
    BROADCAST_MSG
) = range(9)

# ─────────────────────────────────────────────
#  DATA HELPERS
# ─────────────────────────────────────────────
def load_data() -> dict:
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"tournaments": {}, "registrations": {}, "counter": 0}


def save_data(data: dict):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def get_tournament_type_label(t_type: str) -> str:
    labels = {
        "BR":   "🏆 Battle Royale (40 Players)",
        "CS":   "⚔️ Clash Squad 4v4",
        "LONE": "🎯 Lone Wolf 1v1"
    }
    return labels.get(t_type, t_type)


def get_max_players(t_type: str) -> int:
    return {"BR": 40, "CS": 8, "LONE": 2}.get(t_type, 40)

# ─────────────────────────────────────────────
#  KEYBOARDS
# ─────────────────────────────────────────────
def main_menu_keyboard(is_adm: bool) -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton("🏟️ টুর্নামেন্ট লিস্ট", callback_data="list_tournaments")],
        [InlineKeyboardButton("📝 রেজিস্ট্রেশন করুন", callback_data="register_menu")],
        [InlineKeyboardButton("👤 আমার রেজিস্ট্রেশন", callback_data="my_registrations")],
        [InlineKeyboardButton("ℹ️ সাহায্য", callback_data="help")],
    ]
    if is_adm:
        buttons.append([InlineKeyboardButton("⚙️ অ্যাডমিন প্যানেল", callback_data="admin_panel")])
    return InlineKeyboardMarkup(buttons)


def admin_panel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ নতুন টুর্নামেন্ট তৈরি", callback_data="create_tournament")],
        [InlineKeyboardButton("📋 সব টুর্নামেন্ট দেখুন", callback_data="admin_list")],
        [InlineKeyboardButton("👥 রেজিস্ট্রেশন দেখুন", callback_data="view_registrations")],
        [InlineKeyboardButton("📢 ব্রডকাস্ট", callback_data="broadcast")],
        [InlineKeyboardButton("🔙 মেইন মেনু", callback_data="main_menu")],
    ])


def tournament_type_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏆 Battle Royale (BR) - 40 জন", callback_data="type_BR")],
        [InlineKeyboardButton("⚔️ Clash Squad (CS) - 4v4",     callback_data="type_CS")],
        [InlineKeyboardButton("🎯 Lone Wolf - 1v1",              callback_data="type_LONE")],
        [InlineKeyboardButton("❌ বাতিল", callback_data="cancel_create")],
    ])


def back_keyboard(back_cb: str = "main_menu") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("🔙 ফিরে যান", callback_data=back_cb)]])


def tournament_actions_keyboard(t_id: str, is_adm: bool, registered: bool = False) -> InlineKeyboardMarkup:
    buttons = []
    if not registered:
        buttons.append([InlineKeyboardButton("✅ রেজিস্ট্রেশন করুন", callback_data=f"reg_{t_id}")])
    else:
        buttons.append([InlineKeyboardButton("❌ রেজিস্ট্রেশন বাতিল", callback_data=f"unreg_{t_id}")])
    if is_adm:
        buttons += [
            [InlineKeyboardButton("👥 প্লেয়ার লিস্ট", callback_data=f"players_{t_id}")],
            [InlineKeyboardButton("🔑 রুম ইনফো পাঠান", callback_data=f"sendroom_{t_id}")],
            [InlineKeyboardButton("🏁 টুর্নামেন্ট শেষ করুন", callback_data=f"end_{t_id}")],
            [InlineKeyboardButton("🗑️ ডিলিট করুন", callback_data=f"delete_{t_id}")],
        ]
    buttons.append([InlineKeyboardButton("🔙 লিস্টে ফিরুন", callback_data="list_tournaments")])
    return InlineKeyboardMarkup(buttons)

# ─────────────────────────────────────────────
#  /start  /help
# ─────────────────────────────────────────────
async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    adm  = is_admin(user.id)
    text = (
        f"🔥 *Free Fire Tournament Bot* এ স্বাগতম!\n\n"
        f"👋 হ্যালো {user.first_name}!\n\n"
        f"এই বটে আপনি:\n"
        f"• BR (40 জন), CS 4v4, Lone Wolf 1v1 টুর্নামেন্টে অংশ নিতে পারবেন\n"
        f"• রেজিস্ট্রেশন করতে পারবেন\n"
        f"• রুম আইডি ও পাসওয়ার্ড পাবেন\n\n"
        f"{'🛡️ *আপনি অ্যাডমিন!*' if adm else ''}"
    )
    await update.message.reply_text(
        text, parse_mode="Markdown",
        reply_markup=main_menu_keyboard(adm)
    )


async def help_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = (
        "📖 *সাহায্য*\n\n"
        "🏆 *Battle Royale (BR)*\n"
        "  • সর্বোচ্চ ৪০ জন প্লেয়ার\n"
        "  • একা বা স্কোয়াড হিসেবে খেলুন\n\n"
        "⚔️ *Clash Squad (CS) 4v4*\n"
        "  • ৮ জন মোট (২ টিম × ৪ জন)\n"
        "  • টিম বেসড ম্যাচ\n\n"
        "🎯 *Lone Wolf 1v1*\n"
        "  • ২ জন, সরাসরি মুখোমুখি\n\n"
        "📝 রেজিস্ট্রেশনের পর রুম ইনফো পাবেন\n"
        "❓ সমস্যা হলে অ্যাডমিনকে জানান"
    )
    query = update.callback_query
    if query:
        await query.answer()
        await query.edit_message_text(text, parse_mode="Markdown",
                                      reply_markup=back_keyboard())
    else:
        await update.message.reply_text(text, parse_mode="Markdown",
                                        reply_markup=back_keyboard())

# ─────────────────────────────────────────────
#  TOURNAMENT LIST
# ─────────────────────────────────────────────
async def list_tournaments(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = load_data()
    tours = data["tournaments"]

    active = {k: v for k, v in tours.items() if v.get("status") == "open"}
    if not active:
        await query.edit_message_text(
            "😔 এখন কোনো চলমান টুর্নামেন্ট নেই।\nঅ্যাডমিন শীঘ্রই নতুন টুর্নামেন্ট তৈরি করবেন!",
            reply_markup=back_keyboard()
        )
        return

    buttons = []
    for tid, t in active.items():
        reg_count = len(data["registrations"].get(tid, []))
        max_p     = get_max_players(t["type"])
        label     = (
            f"{t['name']} | {t['type']} | "
            f"{reg_count}/{max_p} | {t.get('date','?')}"
        )
        buttons.append([InlineKeyboardButton(label, callback_data=f"view_{tid}")])

    buttons.append([InlineKeyboardButton("🔙 মেইন মেনু", callback_data="main_menu")])
    await query.edit_message_text(
        "🏟️ *চলমান টুর্নামেন্ট সমূহ:*",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def view_tournament(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query  = update.callback_query
    await query.answer()
    t_id   = query.data.replace("view_", "")
    data   = load_data()
    t      = data["tournaments"].get(t_id)
    if not t:
        await query.edit_message_text("❌ টুর্নামেন্ট পাওয়া যায়নি!", reply_markup=back_keyboard())
        return

    regs       = data["registrations"].get(t_id, [])
    max_p      = get_max_players(t["type"])
    user_id    = query.from_user.id
    registered = any(r["user_id"] == user_id for r in regs)

    status_icon = {"open": "🟢", "closed": "🔴", "ended": "⚫"}.get(t.get("status"), "⚪")
    text = (
        f"🏆 *{t['name']}*\n\n"
        f"📌 টাইপ: {get_tournament_type_label(t['type'])}\n"
        f"📅 তারিখ: {t.get('date', 'N/A')}\n"
        f"⏰ সময়: {t.get('time', 'N/A')}\n"
        f"💰 পুরস্কার: {t.get('prize', 'N/A')}\n"
        f"🎫 এন্ট্রি ফি: {t.get('entry_fee', 'বিনামূল্যে')}\n"
        f"👥 রেজিস্ট্রেশন: {len(regs)}/{max_p}\n"
        f"📊 স্ট্যাটাস: {status_icon} {t.get('status', 'open').upper()}\n"
        f"{'✅ আপনি রেজিস্টার্ড' if registered else '❌ আপনি রেজিস্টার্ড নন'}"
    )
    await query.edit_message_text(
        text, parse_mode="Markdown",
        reply_markup=tournament_actions_keyboard(t_id, is_admin(user_id), registered)
    )

# ─────────────────────────────────────────────
#  REGISTRATION
# ─────────────────────────────────────────────
async def register_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data  = load_data()
    active = {k: v for k, v in data["tournaments"].items() if v.get("status") == "open"}
    if not active:
        await query.edit_message_text("😔 কোনো চলমান টুর্নামেন্ট নেই!", reply_markup=back_keyboard())
        return

    buttons = []
    for tid, t in active.items():
        regs  = data["registrations"].get(tid, [])
        max_p = get_max_players(t["type"])
        if len(regs) < max_p:
            buttons.append([InlineKeyboardButton(
                f"📝 {t['name']} ({t['type']}) - {len(regs)}/{max_p}",
                callback_data=f"reg_{tid}"
            )])
    buttons.append([InlineKeyboardButton("🔙 মেইন মেনু", callback_data="main_menu")])
    await query.edit_message_text(
        "📝 *কোন টুর্নামেন্টে রেজিস্টার করবেন?*",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def do_register(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query  = update.callback_query
    await query.answer()
    t_id   = query.data.replace("reg_", "")
    user   = query.from_user
    data   = load_data()
    t      = data["tournaments"].get(t_id)

    if not t:
        await query.edit_message_text("❌ টুর্নামেন্ট পাওয়া যায়নি!")
        return
    if t.get("status") != "open":
        await query.edit_message_text("❌ এই টুর্নামেন্টের রেজিস্ট্রেশন বন্ধ!")
        return

    regs  = data["registrations"].setdefault(t_id, [])
    max_p = get_max_players(t["type"])

    if any(r["user_id"] == user.id for r in regs):
        await query.edit_message_text(
            "⚠️ আপনি আগেই রেজিস্টার করেছেন!",
            reply_markup=back_keyboard("list_tournaments")
        )
        return
    if len(regs) >= max_p:
        await query.edit_message_text("❌ টুর্নামেন্ট পূর্ণ হয়ে গেছে!", reply_markup=back_keyboard())
        return

    regs.append({
        "user_id":    user.id,
        "username":   user.username or "",
        "first_name": user.first_name or "",
        "reg_time":   datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    save_data(data)

    await query.edit_message_text(
        f"✅ *রেজিস্ট্রেশন সফল!*\n\n"
        f"🏆 টুর্নামেন্ট: {t['name']}\n"
        f"📌 টাইপ: {get_tournament_type_label(t['type'])}\n"
        f"📅 তারিখ: {t.get('date','N/A')}\n"
        f"⏰ সময়: {t.get('time','N/A')}\n\n"
        f"রুম ইনফো টুর্নামেন্টের আগে পাঠানো হবে। অপেক্ষায় থাকুন! 🎮",
        parse_mode="Markdown",
        reply_markup=back_keyboard("main_menu")
    )

    # Notify admins
    for aid in ADMIN_IDS:
        try:
            await ctx.bot.send_message(
                aid,
                f"🔔 নতুন রেজিস্ট্রেশন!\n"
                f"টুর্নামেন্ট: {t['name']}\n"
                f"প্লেয়ার: {user.first_name} (@{user.username or 'N/A'})\n"
                f"মোট রেজিস্ট্রেশন: {len(regs)}/{max_p}"
            )
        except Exception:
            pass


async def unregister(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query  = update.callback_query
    await query.answer()
    t_id   = query.data.replace("unreg_", "")
    user   = query.from_user
    data   = load_data()

    regs = data["registrations"].get(t_id, [])
    new_regs = [r for r in regs if r["user_id"] != user.id]
    if len(new_regs) == len(regs):
        await query.edit_message_text("⚠️ আপনি এই টুর্নামেন্টে রেজিস্টার্ড নন!")
        return

    data["registrations"][t_id] = new_regs
    save_data(data)
    await query.edit_message_text(
        "✅ রেজিস্ট্রেশন বাতিল হয়েছে।",
        reply_markup=back_keyboard("list_tournaments")
    )


async def my_registrations(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query   = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data    = load_data()
    found   = []

    for tid, regs in data["registrations"].items():
        for r in regs:
            if r["user_id"] == user_id:
                t = data["tournaments"].get(tid, {})
                found.append((tid, t, r))

    if not found:
        await query.edit_message_text(
            "📭 আপনি এখনো কোনো টুর্নামেন্টে রেজিস্টার করেননি।",
            reply_markup=back_keyboard()
        )
        return

    text = "👤 *আপনার রেজিস্ট্রেশন সমূহ:*\n\n"
    for tid, t, r in found:
        text += (
            f"🏆 {t.get('name','Unknown')}\n"
            f"   📌 {get_tournament_type_label(t.get('type',''))}\n"
            f"   📅 {t.get('date','N/A')} ⏰ {t.get('time','N/A')}\n"
            f"   📊 {t.get('status','').upper()}\n"
            f"   🕐 রেজিস্ট্রেশন: {r.get('reg_time','')}\n\n"
        )
    await query.edit_message_text(text, parse_mode="Markdown", reply_markup=back_keyboard())

# ─────────────────────────────────────────────
#  ADMIN PANEL
# ─────────────────────────────────────────────
async def admin_panel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        await query.edit_message_text("❌ আপনার অ্যাডমিন অ্যাক্সেস নেই!")
        return
    data  = load_data()
    total = len(data["tournaments"])
    opens = sum(1 for t in data["tournaments"].values() if t.get("status") == "open")
    total_regs = sum(len(r) for r in data["registrations"].values())

    await query.edit_message_text(
        f"⚙️ *অ্যাডমিন প্যানেল*\n\n"
        f"📊 মোট টুর্নামেন্ট: {total}\n"
        f"🟢 চলমান: {opens}\n"
        f"👥 মোট রেজিস্ট্রেশন: {total_regs}",
        parse_mode="Markdown",
        reply_markup=admin_panel_keyboard()
    )


# ── Create Tournament (ConversationHandler) ──

async def create_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return ConversationHandler.END
    ctx.user_data["new_t"] = {}
    await query.edit_message_text(
        "➕ *নতুন টুর্নামেন্ট তৈরি করুন*\n\nটুর্নামেন্টের নাম লিখুন:",
        parse_mode="Markdown"
    )
    return CREATE_NAME


async def create_name(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["new_t"]["name"] = update.message.text.strip()
    await update.message.reply_text(
        "📌 টুর্নামেন্টের ধরন বেছে নিন:",
        reply_markup=tournament_type_keyboard()
    )
    return CREATE_TYPE


async def create_type(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    t_type = query.data.replace("type_", "")
    ctx.user_data["new_t"]["type"] = t_type
    await query.edit_message_text(
        f"✅ ধরন: {get_tournament_type_label(t_type)}\n\nতারিখ লিখুন (যেমন: 25 June 2025):"
    )
    return CREATE_DATE


async def create_date(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["new_t"]["date"] = update.message.text.strip()
    await update.message.reply_text("⏰ সময় লিখুন (যেমন: 8:00 PM):")
    return CREATE_TIME


async def create_time(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["new_t"]["time"] = update.message.text.strip()
    await update.message.reply_text("💰 পুরস্কার লিখুন (যেমন: 500 TK বা Diamond):")
    return CREATE_PRIZE


async def create_prize(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["new_t"]["prize"] = update.message.text.strip()
    await update.message.reply_text("🎫 এন্ট্রি ফি লিখুন (0 মানে বিনামূল্যে):")
    return CREATE_ENTRY_FEE


async def create_entry_fee(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    fee = update.message.text.strip()
    ctx.user_data["new_t"]["entry_fee"] = "বিনামূল্যে" if fee == "0" else fee
    await update.message.reply_text(
        "🔑 রুম আইডি লিখুন (পরে সেট করতে চাইলে 'skip' লিখুন):"
    )
    return CREATE_ROOM_ID


async def create_room_id(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    val = update.message.text.strip()
    ctx.user_data["new_t"]["room_id"] = "" if val.lower() == "skip" else val
    await update.message.reply_text(
        "🔒 রুম পাসওয়ার্ড লিখুন (skip করতে 'skip' লিখুন):"
    )
    return CREATE_ROOM_PASS


async def create_room_pass(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    val = update.message.text.strip()
    ctx.user_data["new_t"]["room_pass"] = "" if val.lower() == "skip" else val

    data = load_data()
    data["counter"] += 1
    t_id = f"T{data['counter']:04d}"
    new_t = ctx.user_data["new_t"]
    new_t.update({
        "status":     "open",
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "created_by": update.effective_user.id
    })
    data["tournaments"][t_id] = new_t
    data["registrations"][t_id] = []
    save_data(data)

    max_p = get_max_players(new_t["type"])
    await update.message.reply_text(
        f"✅ *টুর্নামেন্ট তৈরি হয়েছে!*\n\n"
        f"🆔 ID: `{t_id}`\n"
        f"🏆 নাম: {new_t['name']}\n"
        f"📌 ধরন: {get_tournament_type_label(new_t['type'])}\n"
        f"👥 সর্বোচ্চ প্লেয়ার: {max_p}\n"
        f"📅 তারিখ: {new_t['date']}\n"
        f"⏰ সময়: {new_t['time']}\n"
        f"💰 পুরস্কার: {new_t['prize']}\n"
        f"🎫 এন্ট্রি ফি: {new_t['entry_fee']}",
        parse_mode="Markdown",
        reply_markup=admin_panel_keyboard()
    )
    ctx.user_data.clear()
    return ConversationHandler.END


async def cancel_create(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data.clear()
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            "❌ বাতিল করা হয়েছে।",
            reply_markup=admin_panel_keyboard()
        )
    else:
        await update.message.reply_text("❌ বাতিল।", reply_markup=admin_panel_keyboard())
    return ConversationHandler.END


# ── View & Manage Players ──

async def view_players(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    t_id = query.data.replace("players_", "")
    data = load_data()
    t    = data["tournaments"].get(t_id, {})
    regs = data["registrations"].get(t_id, [])

    if not regs:
        await query.edit_message_text(
            f"😔 *{t.get('name',t_id)}*\n\nএখনো কোনো প্লেয়ার রেজিস্টার করেনি।",
            parse_mode="Markdown",
            reply_markup=back_keyboard("admin_list")
        )
        return

    text = f"👥 *{t.get('name',t_id)} - প্লেয়ার লিস্ট ({len(regs)}/{get_max_players(t.get('type','BR'))}):*\n\n"
    for i, r in enumerate(regs, 1):
        uname = f"@{r['username']}" if r.get("username") else r.get("first_name", "Unknown")
        text += f"{i}. {r.get('first_name','')} {uname} | ID: `{r['user_id']}`\n"

    await query.edit_message_text(
        text, parse_mode="Markdown",
        reply_markup=back_keyboard("admin_list")
    )


async def view_registrations(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    data  = load_data()
    tours = data["tournaments"]
    if not tours:
        await query.edit_message_text("📭 কোনো টুর্নামেন্ট নেই।", reply_markup=back_keyboard("admin_panel"))
        return

    buttons = []
    for tid, t in tours.items():
        regs  = data["registrations"].get(tid, [])
        max_p = get_max_players(t["type"])
        buttons.append([InlineKeyboardButton(
            f"👥 {t['name']} ({len(regs)}/{max_p})",
            callback_data=f"players_{tid}"
        )])
    buttons.append([InlineKeyboardButton("🔙 অ্যাডমিন প্যানেল", callback_data="admin_panel")])
    await query.edit_message_text(
        "📋 *টুর্নামেন্ট রেজিস্ট্রেশন দেখুন:*",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def admin_list(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    data  = load_data()
    tours = data["tournaments"]
    if not tours:
        await query.edit_message_text("📭 কোনো টুর্নামেন্ট নেই।", reply_markup=back_keyboard("admin_panel"))
        return

    buttons = []
    for tid, t in tours.items():
        regs  = data["registrations"].get(tid, [])
        max_p = get_max_players(t["type"])
        icon  = {"open": "🟢", "closed": "🔴", "ended": "⚫"}.get(t.get("status"), "⚪")
        buttons.append([InlineKeyboardButton(
            f"{icon} {t['name']} | {t['type']} | {len(regs)}/{max_p}",
            callback_data=f"view_{tid}"
        )])
    buttons.append([InlineKeyboardButton("🔙 অ্যাডমিন প্যানেল", callback_data="admin_panel")])
    await query.edit_message_text(
        "📋 *সব টুর্নামেন্ট:*",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def send_room_info(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    t_id = query.data.replace("sendroom_", "")
    data = load_data()
    t    = data["tournaments"].get(t_id, {})
    regs = data["registrations"].get(t_id, [])

    room_id   = t.get("room_id", "")
    room_pass = t.get("room_pass", "")

    if not room_id:
        await query.answer("⚠️ রুম আইডি সেট করা নেই! /setroom কমান্ড ব্যবহার করুন।", show_alert=True)
        return

    msg = (
        f"🎮 *{t.get('name','')} - রুম ইনফো*\n\n"
        f"🆔 রুম আইডি: `{room_id}`\n"
        f"🔑 পাসওয়ার্ড: `{room_pass}`\n\n"
        f"📅 তারিখ: {t.get('date','')}\n"
        f"⏰ সময়: {t.get('time','')}\n\n"
        f"⚠️ সময়মতো জয়েন করুন, দেরিতে জয়েন করলে বাদ পড়বেন!\n"
        f"🏆 পুরস্কার: {t.get('prize','')}"
    )

    sent, failed = 0, 0
    for r in regs:
        try:
            await ctx.bot.send_message(r["user_id"], msg, parse_mode="Markdown")
            sent += 1
        except Exception:
            failed += 1

    await query.answer(f"✅ পাঠানো হয়েছে: {sent} জনকে | ❌ ব্যর্থ: {failed}", show_alert=True)


async def end_tournament(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    t_id = query.data.replace("end_", "")
    data = load_data()
    if t_id in data["tournaments"]:
        data["tournaments"][t_id]["status"] = "ended"
        save_data(data)
        await query.answer("✅ টুর্নামেন্ট শেষ করা হয়েছে!", show_alert=True)
        # refresh view
        await admin_list(update, ctx)


async def delete_tournament(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    t_id = query.data.replace("delete_", "")
    data = load_data()
    name = data["tournaments"].get(t_id, {}).get("name", t_id)
    data["tournaments"].pop(t_id, None)
    data["registrations"].pop(t_id, None)
    save_data(data)
    await query.answer(f"🗑️ '{name}' ডিলিট করা হয়েছে!", show_alert=True)
    await admin_list(update, ctx)


# ── Broadcast ──

async def broadcast_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return ConversationHandler.END
    await query.edit_message_text(
        "📢 *ব্রডকাস্ট বার্তা*\n\nসব রেজিস্টার্ড প্লেয়ারকে পাঠাতে চান এমন বার্তা লিখুন:\n\n(বাতিল করতে /cancel লিখুন)",
        parse_mode="Markdown"
    )
    return BROADCAST_MSG


async def broadcast_send(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg_text = update.message.text
    data     = load_data()
    all_users = set()
    for regs in data["registrations"].values():
        for r in regs:
            all_users.add(r["user_id"])

    sent, failed = 0, 0
    for uid in all_users:
        try:
            await ctx.bot.send_message(
                uid,
                f"📢 *অ্যাডমিন বার্তা:*\n\n{msg_text}",
                parse_mode="Markdown"
            )
            sent += 1
        except Exception:
            failed += 1

    await update.message.reply_text(
        f"✅ ব্রডকাস্ট সম্পন্ন!\n📤 পাঠানো হয়েছে: {sent}\n❌ ব্যর্থ: {failed}",
        reply_markup=admin_panel_keyboard()
    )
    return ConversationHandler.END


# ── /setroom command ──

async def setroom(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ অ্যাডমিন অ্যাক্সেস নেই!")
        return
    args = ctx.args
    if len(args) < 3:
        await update.message.reply_text(
            "ব্যবহার: `/setroom <tournament_id> <room_id> <password>`\n"
            "উদাহরণ: `/setroom T0001 123456 ff2024`",
            parse_mode="Markdown"
        )
        return
    t_id, room_id, room_pass = args[0], args[1], args[2]
    data = load_data()
    if t_id not in data["tournaments"]:
        await update.message.reply_text(f"❌ টুর্নামেন্ট `{t_id}` পাওয়া যায়নি!", parse_mode="Markdown")
        return
    data["tournaments"][t_id]["room_id"]   = room_id
    data["tournaments"][t_id]["room_pass"] = room_pass
    save_data(data)
    await update.message.reply_text(
        f"✅ রুম ইনফো সেট হয়েছে!\n🆔 রুম ID: `{room_id}`\n🔑 পাসওয়ার্ড: `{room_pass}`",
        parse_mode="Markdown"
    )


# ── Main menu callback ──

async def main_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user
    await query.edit_message_text(
        f"🔥 *Free Fire Tournament Bot*\n\nমেইন মেনু:",
        parse_mode="Markdown",
        reply_markup=main_menu_keyboard(is_admin(user.id))
    )

# ─────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # Conversation: Create Tournament
    create_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(create_start, pattern="^create_tournament$")],
        states={
            CREATE_NAME:      [MessageHandler(filters.TEXT & ~filters.COMMAND, create_name)],
            CREATE_TYPE:      [CallbackQueryHandler(create_type, pattern="^type_")],
            CREATE_DATE:      [MessageHandler(filters.TEXT & ~filters.COMMAND, create_date)],
            CREATE_TIME:      [MessageHandler(filters.TEXT & ~filters.COMMAND, create_time)],
            CREATE_PRIZE:     [MessageHandler(filters.TEXT & ~filters.COMMAND, create_prize)],
            CREATE_ENTRY_FEE: [MessageHandler(filters.TEXT & ~filters.COMMAND, create_entry_fee)],
            CREATE_ROOM_ID:   [MessageHandler(filters.TEXT & ~filters.COMMAND, create_room_id)],
            CREATE_ROOM_PASS: [MessageHandler(filters.TEXT & ~filters.COMMAND, create_room_pass)],
        },
        fallbacks=[
            CallbackQueryHandler(cancel_create, pattern="^cancel_create$"),
            CommandHandler("cancel", cancel_create),
        ],
    )

    # Conversation: Broadcast
    broadcast_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(broadcast_start, pattern="^broadcast$")],
        states={
            BROADCAST_MSG: [MessageHandler(filters.TEXT & ~filters.COMMAND, broadcast_send)],
        },
        fallbacks=[CommandHandler("cancel", cancel_create)],
    )

    # Register handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help",  help_cmd))
    app.add_handler(CommandHandler("setroom", setroom))
    app.add_handler(create_conv)
    app.add_handler(broadcast_conv)

    # Callback handlers
    app.add_handler(CallbackQueryHandler(main_menu,           pattern="^main_menu$"))
    app.add_handler(CallbackQueryHandler(admin_panel,         pattern="^admin_panel$"))
    app.add_handler(CallbackQueryHandler(list_tournaments,    pattern="^list_tournaments$"))
    app.add_handler(CallbackQueryHandler(register_menu,       pattern="^register_menu$"))
    app.add_handler(CallbackQueryHandler(my_registrations,    pattern="^my_registrations$"))
    app.add_handler(CallbackQueryHandler(help_cmd,            pattern="^help$"))
    app.add_handler(CallbackQueryHandler(admin_list,          pattern="^admin_list$"))
    app.add_handler(CallbackQueryHandler(view_registrations,  pattern="^view_registrations$"))
    app.add_handler(CallbackQueryHandler(view_tournament,     pattern="^view_T"))
    app.add_handler(CallbackQueryHandler(do_register,         pattern="^reg_T"))
    app.add_handler(CallbackQueryHandler(unregister,          pattern="^unreg_T"))
    app.add_handler(CallbackQueryHandler(view_players,        pattern="^players_T"))
    app.add_handler(CallbackQueryHandler(send_room_info,      pattern="^sendroom_T"))
    app.add_handler(CallbackQueryHandler(end_tournament,      pattern="^end_T"))
    app.add_handler(CallbackQueryHandler(delete_tournament,   pattern="^delete_T"))

    print("🤖 Free Fire Tournament Bot চালু হচ্ছে...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()